﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Reloj Windows .NET 4.8")]
[assembly: AssemblyDescription("Reloj Windows es una aplicación que muestra la fecha y hora y se puede usar casi como un salvapantalla. Permite acoplarlo a la parte superior derecha o izquierda.  (para .NET Framework 4.8 revisión del 05-dic-2020)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("elGuille")]
[assembly: AssemblyProduct("Reloj Windows .NET 4.8")]
[assembly: AssemblyCopyright("© Guillermo Som (elGuille), 2020")]
[assembly: AssemblyTrademark("Microsoft Visual C# 2019 (.NET 4.8)")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("83edb80c-2bc2-4f60-91fb-87fde1623607")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.1")]
